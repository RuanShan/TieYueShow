$(document).ready(function(){

  videojs(document.querySelector('.video-js'));
});
